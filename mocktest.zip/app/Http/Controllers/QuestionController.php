<?php

namespace App\Http\Controllers;

use App\Models\Question;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    public function save_question(Request $request)
    {
        $request->validate([
           'question' => 'required',
           'options' => 'required|array|length:4',
           'answer' => 'required'
        ]);

        $question = Question::create([

        ]);

        dd($request->all());
    }
}
